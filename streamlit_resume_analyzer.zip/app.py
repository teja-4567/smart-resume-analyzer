
import streamlit as st
import pdfplumber

def extract_text_from_pdf(file):
    with pdfplumber.open(file) as pdf:
        text = ''
        for page in pdf.pages:
            text += page.extract_text()
    return text

def load_keywords():
    return [
        "python", "sql", "oop", "problem solving", "data structures",
        "algorithms", "teamwork", "communication", "agile",
        "debugging", "coding", "development", "software engineering", "unit testing"
    ]

def analyze_resume(text, keywords):
    found = []
    missing = []

    text = text.lower()
    for keyword in keywords:
        if keyword in text:
            found.append(keyword)
        else:
            missing.append(keyword)

    score = int(len(found) / len(keywords) * 100)
    return found, missing, score

st.set_page_config(page_title="Smart Resume Analyzer - TCS NQT Edition", layout="centered")
st.title("📄 Smart Resume Analyzer")
st.subheader("Optimize your resume for TCS NQT with AI-based keyword matching")

uploaded_file = st.file_uploader("Upload your resume (.pdf only)", type=["pdf"])

if uploaded_file is not None:
    with st.spinner("Analyzing your resume..."):
        text = extract_text_from_pdf(uploaded_file)
        keywords = load_keywords()
        found, missing, score = analyze_resume(text, keywords)

        st.success(f"✅ Resume Score: {score}/100")
        st.markdown("### ✅ Keywords Found")
        st.write(", ".join(found))
        st.markdown("### ❌ Keywords Missing")
        st.write(", ".join(missing))

        if missing:
            st.markdown("### 💡 Suggestions")
            st.info("Try adding projects or experiences that include the missing keywords above to improve your TCS NQT readiness.")
